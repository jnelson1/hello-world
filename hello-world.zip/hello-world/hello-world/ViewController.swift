//
//  ViewController.swift
//  hello-world
//
//  Created by Jon Nelson1 on 5/22/17.
//  Copyright © 2017 Jon Nelson. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

